## mypackage
This library was created as an examply of how to publish your own Python package.

### How to install
...